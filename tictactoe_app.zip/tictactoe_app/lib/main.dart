import 'package:flutter/material.dart';

void main() {
  runApp(const TictactoeApp());
}

class TictactoeApp extends StatelessWidget {
  const TictactoeApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Tictactoe',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color.fromARGB(255, 58, 183, 75)),
      ),
      home: const MyHomePage(title: 'Tictactoe Page'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});

  final String title;

  @override
  State<MyHomePage> createState() => _TictactoePageState();
}

class _TictactoePageState extends State<MyHomePage> {
  String winner = "";
  String player = "";
  bool draw = false;
  String block11 = "";String block21 = "";String block31 = "";
  String block12 = "";String block22 = "";String block32 = "";
  String block13 = "";String block23 = "";String block33 = "";
  void _incrementCounter() {
    setState(() {
      void _blockRows(){
        if(block11 == "X" && block21 == "X" && block31 == "X"){
          winner = "X";
        }
        if(block12 == "X" && block22 == "X" && block32 == "X"){
          winner = "X";
        }
        if(block13 == "X" && block23 == "X" && block33 == "X"){
          winner = "X";
        }
        if(block11 == "O" && block21 == "O" && block31 == "O"){
          winner = "O";
        }
        if(block12 == "O" && block22 == "O" && block32 == "O"){
          winner = "O";
        }
        if(block13 == "O" && block23 == "O" && block33 == "O"){
          winner = "O";
        }
      }
      void _blockColums(){
        if(block11 == "X" && block12 == "X" && block13 == "X"){
          winner = "X";
        }
        if(block21 == "X" && block22 == "X" && block23 == "X"){
          winner = "X";
        }
        if(block31 == "X" && block32 == "X" && block33 == "X"){
          winner = "X";
        }
        if(block11 == "O" && block12 == "O" && block13 == "O"){
          winner = "O";
        }
        if(block21 == "O" && block22 == "O" && block23 == "O"){
          winner = "O";
        }
        if(block31 == "O" && block32 == "O" && block33 == "O"){
          winner = "O";
        }
      }
      void _blockX(){
        if(block11 == "X" && block22 == "X" && block33 == "X"){
          winner = "X";
        }
        if(block31 == "X" && block22 == "X" && block13 == "X"){
          winner = "X";
        }
        if(block11 == "O" && block22 == "O" && block33 == "O"){
          winner = "O";
        }
        if(block31 == "O" && block22 == "O" && block13 == "O"){
          winner = "O";
        }
      }
    });
  }
  
  String _blockWrite(String g){
      if(g == ""){
        if(player == "X"){
          player = "O";
          g = "X";
        }
        else if(player == "O"){
          player = "X";
          g = "O";
        }
      }
      return g;
    }

    void _block11Write(){
       setState(() {block11 = _blockWrite(block11);});}
    void _block12Write(){
       setState(() { block12 = _blockWrite(block12);});}
    void _block13Write(){
       setState(() {block13 = _blockWrite(block13);});}

    void _block21Write(){
       setState(() {block21 = _blockWrite(block21);});}
    void _block22Write(){
       setState(() { block22 = _blockWrite(block22);});}
    void _block23Write(){
       setState(() {block23 = _blockWrite(block23);});}

    void _block31Write(){
       setState(() {block31 = _blockWrite(block31);});}
    void _block32Write(){
       setState(() { block32 = _blockWrite(block32);});}
    void _block33Write(){
       setState(() {block33 = _blockWrite(block33);});}

  void _resetAll(){
    setState(() {
      player = "O";
      block11 = "";block21 = "";block31 = "";
      block12 = "";block22 = "";block32 = "";
      block13 = "";block23 = "";block33 = "";
    });
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        title: Text(widget.title),
      ),
      body: Container(
        child: Column(
          children:[
              FloatingActionButton(
              onPressed: () {_block11Write();},
              child: Text(block11),),
              FloatingActionButton(
              onPressed: () {_block12Write();},
              child: Text(block12),),
              FloatingActionButton(
              onPressed: () {_block13Write();},
              child: Text(block13),),

              FloatingActionButton(
              onPressed: () {_block21Write();},
              child: Text(block21),),
              FloatingActionButton(
              onPressed: () {_block22Write();},
              child: Text(block22),),
              FloatingActionButton(
              onPressed: () {_block23Write();},
              child: Text(block23),),

              FloatingActionButton(
              onPressed: () {_block31Write();},
              child: Text(block31),),
              FloatingActionButton(
              onPressed: () {_block32Write();},
              child: Text(block32),),
              FloatingActionButton(
              onPressed: () {_block33Write();},
              child: Text(block33),),

              FloatingActionButton(
              onPressed: () {_resetAll();},
              child: Text("Return"),),
          ],
        )
        
      ),
    );
  }
}
