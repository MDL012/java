<template>
    <h1>Foglalás</h1>
</template>

<style>
</style>
