﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace SzámnégyesekServer.WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SqliteController : ControllerBase
    {
        private readonly Convert _Context = new();

        [HttpGet]
        public async Task<IActionResult> GetAllAsync()
        {
            return Ok(await _Context.NegySzams.ToListAsync());
        }
    }
}