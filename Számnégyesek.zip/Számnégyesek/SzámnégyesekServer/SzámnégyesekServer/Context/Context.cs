﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using SzámnégyesekServer.Model;

namespace SzámnégyesekServer.Context
{
    public partial class Context : DbContext
    {
        public DbSet<NegySzam> NegySzams { get; set; }

        public Context(DbContextOptions<Context> options) : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Seed();
            base.OnModelCreating(modelBuilder);
        }
    }
}
