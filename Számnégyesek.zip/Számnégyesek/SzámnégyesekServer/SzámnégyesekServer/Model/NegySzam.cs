﻿namespace SzámnégyesekServer.Model
{
    public partial class NegySzam
    {
        public int[] Index { get; set; }
        public int[] Szamnegyes { get; set; }
    }
}
