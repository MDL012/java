﻿using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Számnégyesek.ViewModel
{
    public partial class MainViewModel : ObservableObject, INotifyPropertyChanged
    {
        [ObservableProperty]
        private object _szam;
        int[] szamok = { 0, 0, 0, 0, 0, 0, 0, 0, 0 };

        public MainViewModel()
        {
            Szam = szamok;
        }

        [RelayCommand]
        private void buttonA()
        {
            szamok[0]++; szamok[1]++; szamok[3]++; szamok[4]++;
            Szam = szamok;
            OnPropertyChanged(nameof(Szam));
        }

        [RelayCommand]
        private void buttonB()
        {
            szamok[1]++; szamok[2]++; szamok[4]++; szamok[5]++;
            Szam = szamok;
            OnPropertyChanged(nameof(Szam));
        }

        [RelayCommand]
        private void buttonC()
        {
            szamok[3]++; szamok[4]++; szamok[6]++; szamok[7]++;
            Szam = szamok;
            OnPropertyChanged(nameof(Szam));
        }

        [RelayCommand]
        private void buttonD()
        {
            szamok[4]++; szamok[5]++; szamok[7]++; szamok[8]++;
            Szam = szamok;
            OnPropertyChanged(nameof(Szam));
        }

        [RelayCommand]
        private void buttonNull()
        {
            for (int i = 0; i < szamok.Length; i++)
            {
                szamok[i] = 0;
            }
            Szam = szamok;
            OnPropertyChanged(nameof(Szam));
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
